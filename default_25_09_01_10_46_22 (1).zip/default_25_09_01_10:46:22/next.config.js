module.exports = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  },
  env: {
    NEXTAUTH_URL: process.env.NEXTAUTH_URL
  }
};
