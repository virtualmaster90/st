import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";
const SECRET = process.env.NEXTAUTH_SECRET;
export async function GET(req: Request) {
  const token = await getToken({ req, secret: SECRET });
  if (!token?.sub) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = String(token.sub);
  const chats = await prisma.chat.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50 });
  return NextResponse.json({ chats });
}
