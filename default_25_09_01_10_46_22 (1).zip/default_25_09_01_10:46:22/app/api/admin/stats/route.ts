import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";
const SECRET = process.env.NEXTAUTH_SECRET;
export async function GET(req: Request) {
  const token = await getToken({ req, secret: SECRET });
  if (!token?.sub) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const role = (token as any).role ?? "USER";
  if (role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const totalUsers = await prisma.user.count();
  const totalChats = await prisma.chat.count();
  const recentChats = await prisma.chat.findMany({ take: 10, orderBy: { createdAt: "desc" } });
  return NextResponse.json({ totalUsers, totalChats, recentChats });
}
