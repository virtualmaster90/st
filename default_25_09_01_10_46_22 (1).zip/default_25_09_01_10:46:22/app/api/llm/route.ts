import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/lib/prisma";
import { RateLimiter } from "@/lib/rate-limit";
import { sanitizePrompt } from "@/lib/sanitize";
import { generateLLMResponse } from "@/lib/llm";

const rateLimiter = new RateLimiter();
const SECRET = process.env.NEXTAUTH_SECRET;

export async function POST(req: Request) {
  const token = await getToken({ req, secret: SECRET });
  if (!token?.sub) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = String(token.sub);
  const json = await req.json().catch(() => null);
  const promptRaw = json?.prompt;
  if (typeof promptRaw !== "string") return NextResponse.json({ error: "Invalid prompt" }, { status: 400 });
  const prompt = sanitizePrompt(promptRaw, 2000);
  if (!prompt) return NextResponse.json({ error: "Empty prompt after sanitization" }, { status: 400 });
  const { limited } = await rateLimiter.consume(`rl:${userId}`);
  if (limited) return NextResponse.json({ error: "Rate limit exceeded" }, { status: 429 });
  const llmRes = await generateLLMResponse({ userId, prompt, maxTokens: 512 });
  await prisma.chat.create({ data: { userId, prompt, response: llmRes.text } });
  return NextResponse.json({ response: llmRes.text, usageTokens: llmRes.usageTokens });
}
