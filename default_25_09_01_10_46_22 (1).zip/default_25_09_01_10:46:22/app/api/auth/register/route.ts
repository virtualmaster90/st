import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function POST(req: Request) {
  const data = await req.json().catch(() => null);
  if (!data || !data.email || !data.password) return NextResponse.json({ error: "Missing email or password" }, { status: 400 });
  const email = String(data.email).toLowerCase();
  const password = String(data.password);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ error: "Invalid email" }, { status: 400 });
  if (password.length < 8) return NextResponse.json({ error: "Password must be at least 8 characters" }, { status: 400 });
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return NextResponse.json({ error: "Email already registered" }, { status: 409 });
  const hashed = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({ data: { email, password: hashed, name: data.name ?? null } });
  return NextResponse.json({ id: user.id, email: user.email, name: user.name }, { status: 201 });
}
