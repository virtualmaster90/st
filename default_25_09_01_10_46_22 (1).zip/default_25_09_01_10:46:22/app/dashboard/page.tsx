"use client";
import { useState } from "react";
import { useSession, signOut } from "next-auth/react";
export default function Dashboard() {
  const { data: session } = useSession();
  const [prompt, setPrompt] = useState("");
  const [responses, setResponses] = useState<{ id: string; text: string }[]>([]);
  const [loading, setLoading] = useState(false);
  if (!session) return <div>Loading session...</div>;
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;
    setLoading(true);
    try {
      const res = await fetch("/api/llm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt }) });
      const js = await res.json();
      if (res.ok) {
        setResponses(prev => [{ id: Date.now().toString(), text: js.response }, ...prev]);
      } else {
        alert(js.error || "Error");
      }
    } finally {
      setLoading(false);
      setPrompt("");
    }
  };
  return (
    <div style={{ padding: 20 }}>
      <h2>Dashboard</h2>
      <div>
        <strong>{session.user?.email}</strong> ({(session.user as any)?.role})
        <button onClick={() => signOut({ callbackUrl: "/" })} style={{ marginLeft: 10 }}>Sign out</button>
      </div>
      <form onSubmit={handleSubmit} style={{ marginTop: 20 }}>
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={4} style={{ width: "100%" }} />
        <button type="submit" disabled={loading} style={{ marginTop: 8 }}>{loading ? "Thinking..." : "Send"}</button>
      </form>
      <div style={{ marginTop: 20 }}>
        <h3>Responses</h3>
        {responses.map(r => <div key={r.id} style={{ border: "1px solid #ddd", padding: 8, marginBottom: 8 }}>{r.text}</div>)}
      </div>
    </div>
  );
}
