import Link from "next/link";
export default function Home() {
  return (
    <main style={{ padding: 20 }}>
      <h1>Welcome</h1>
      <p>
        <Link href="/api/auth/signin">Sign in</Link> or{" "}
        <Link href="/api/auth/register">Register (use POST /api/auth/register)</Link>
      </p>
      <p>
        <a href="/dashboard">Go to dashboard (requires sign in)</a>
      </p>
    </main>
  );
}
