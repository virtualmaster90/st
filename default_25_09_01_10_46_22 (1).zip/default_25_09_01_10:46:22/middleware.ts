import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getToken } from "next-auth/jwt";
const SECRET = process.env.NEXTAUTH_SECRET;

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const protectedPrefixes = ["/dashboard", "/api/llm", "/api/admin"];
  const shouldProtect = protectedPrefixes.some(p => pathname.startsWith(p));
  if (!shouldProtect) return NextResponse.next();
  const token = await getToken({ req, secret: SECRET });
  if (!token) {
    if (pathname.startsWith("/api/")) return new NextResponse(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { "content-type": "application/json" } });
    const url = req.nextUrl.clone();
    url.pathname = "/";
    url.searchParams.set("error", "auth");
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}
