import { describe, it, expect } from "vitest";
import { RateLimiter } from "../../lib/rate-limit";

describe("RateLimiter in-memory", () => {
  it("allows under limit and blocks over limit", async () => {
    const rl = new RateLimiter();
    const key = "test-user";
    // consume a couple times and ensure remaining and limited behave
    for (let i = 0; i < 2; i++) {
      const res = await rl.consume(key, 1);
      expect(res).toHaveProperty("remaining");
      expect(res.limited).toBe(false);
    }
    // simulate exceeding the limit by consuming a large amount
    const bigConsume = await rl.consume(key, Number(process.env.RATE_LIMIT_PER_MINUTE || 60));
    expect(bigConsume).toHaveProperty("remaining");
  });
});
