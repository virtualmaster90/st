import OpenAI from "openai";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateLLMResponse({
  userId,
  prompt,
  maxTokens = 512
}: {
  userId: string;
  prompt: string;
  maxTokens?: number;
}): Promise<{ text: string; usageTokens?: number }> {
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
  const response = await client.chat.completions.create({
    model,
    messages: [
      { role: "system", content: "You are a helpful assistant that follows security policies." },
      { role: "user", content: prompt }
    ],
    max_tokens: maxTokens,
    temperature: 0.2
  });
  const first = response.choices?.[0]?.message?.content ?? "";
  const usageTokens = response.usage?.total_tokens;
  return { text: String(first), usageTokens };
}
