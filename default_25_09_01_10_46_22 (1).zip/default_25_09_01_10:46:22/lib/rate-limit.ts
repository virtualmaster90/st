import Redis from "ioredis";
const RATE_LIMIT_PER_MINUTE = Number(process.env.RATE_LIMIT_PER_MINUTE || 60);
const WINDOW_MS = 60 * 1000;

let redis: Redis | null = null;
if (process.env.REDIS_URL) redis = new Redis(process.env.REDIS_URL);

type Entry = { count: number; expiresAt: number };
const memoryStore = new Map<string, Entry>();

export class RateLimiter {
  async consume(key: string, points = 1): Promise<{ remaining: number; limited: boolean }> {
    if (redis) {
      const now = Date.now();
      const window = WINDOW_MS;
      const res = await redis.multi()
        .incrby(key, points)
        .pexpire(key, window)
        .pttl(key)
        .exec();
      const incr = (res?.[0]?.[1] as number) || 0;
      const ttl = (res?.[2]?.[1] as number) || window;
      const remaining = Math.max(RATE_LIMIT_PER_MINUTE - incr, 0);
      return { remaining, limited: incr > RATE_LIMIT_PER_MINUTE };
    } else {
      const entry = memoryStore.get(key);
      const now = Date.now();
      if (!entry || entry.expiresAt <= now) {
        memoryStore.set(key, { count: points, expiresAt: now + WINDOW_MS });
        return { remaining: RATE_LIMIT_PER_MINUTE - points, limited: points > RATE_LIMIT_PER_MINUTE };
      }
      entry.count += points;
      memoryStore.set(key, entry);
      return { remaining: Math.max(RATE_LIMIT_PER_MINUTE - entry.count, 0), limited: entry.count > RATE_LIMIT_PER_MINUTE };
    }
  }
}
