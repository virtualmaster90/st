import sanitizeHtml from "sanitize-html";
export function sanitizePrompt(prompt: string, maxLength = 2000): string {
  if (!prompt) return "";
  const trimmed = prompt.trim().slice(0, maxLength);
  return sanitizeHtml(trimmed, {
    allowedTags: [],
    allowedAttributes: {}
  });
}
