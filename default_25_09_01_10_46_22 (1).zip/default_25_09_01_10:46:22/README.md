# NextAuth + LLM Next.js App

This repository provides a Next.js App Router (TypeScript) application with NextAuth authentication (Credentials + Google), Prisma for PostgreSQL, an OpenAI integration for LLM responses, rate limiting (Redis or in-memory fallback), and a small dashboard.

Quick start:

1) Install dependencies:
   npm install

2) Create .env file:
   cp .env.example .env
   Edit .env and set the following variables:
   - DATABASE_URL
   - NEXTAUTH_URL
   - NEXTAUTH_SECRET
   - GOOGLE_CLIENT_ID
   - GOOGLE_CLIENT_SECRET
   - OPENAI_API_KEY
   - OPENAI_MODEL
   (optional) REDIS_URL, RATE_LIMIT_PER_MINUTE

3) Prisma:
   - If your repo already uses Prisma:
       npx prisma generate
       npx prisma migrate dev --name add_auth_and_chat
   - If not:
       npm install prisma @prisma/client
       npx prisma init --datasource-provider postgresql
       Replace prisma/schema.prisma with the provided file.
       npx prisma generate
       npx prisma migrate dev --name init

4) Start dev:
   npm run dev

5) Production build:
   npm run build
   npm run start

Google OAuth:
- Create OAuth credentials at https://console.developers.google.com/apis/credentials
- Make sure Authorized redirect URI includes:
  http://localhost:3000/api/auth/callback/google
- Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env

OpenAI:
- Set OPENAI_API_KEY and OPENAI_MODEL in .env. Do not commit your API keys.

Security:
- Set NEXTAUTH_SECRET to a strong random string.
- Passwords are hashed with bcrypt.
- Use Redis in production for rate limiting; in-memory fallback used for local development.
- Do not log secrets.

Docker (optional):
- Use Dockerfile and docker-compose.yml to run Postgres, Redis and the app.

Testing:
- Run unit tests:
   npm run test

Prisma Schema:
- See prisma/schema.prisma

Notes:
- If you change imports using `@/...` make sure tsconfig paths are configured (they are in this project).
- app/layout.tsx imports a simple globals.css; edit styles as needed.
